<?php return array('dependencies' => array('react', 'wp-block-editor', 'wp-blocks', 'wp-components', 'wp-hooks'), 'version' => '08ebc7abee6f7075ac53');
